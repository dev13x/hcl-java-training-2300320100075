package com.hcl.hclassessment2.controllers;
@RestController
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/add/{productId}")
    public Cart addToCart(@PathVariable int productId) {
        return cartService.addProduct(productId);
    }

    @GetMapping
    public Cart viewCart() {
        return cartService.getCart();
    }

    @DeleteMapping("/remove/{productId}")
    public Cart removeFromCart(@PathVariable int productId) {
        return cartService.removeProduct(productId);
    }
}
